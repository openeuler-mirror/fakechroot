#!/bin/sh

echo ${FAKECHROOT_CMD_ORIG:-(null)}
